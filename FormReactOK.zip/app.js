const form = document.getElementById('contactForm');

form.addEventListener('submit', (event) => {
    event.preventDefault();
    const formData = new FormData(form);

    const errors = {
        firstName: document.getElementById('firstNameError'),
        lastName: document.getElementById('lastNameError'),
        email: document.getElementById('emailError'),
        phone: document.getElementById('phoneError'),
        message: document.getElementById('messageError')
    }
    const phoneRegex = /^(?:(?:\+|00)33|0)\s*[1-9](?:[\s.-]*\d{2}){4}$/;
    const emailRegex = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
    const firstNameRegex = /^[a-zA-Z ]+$/;
    const lastNameRegex = /^[a-zA-Z ]+$/;


    let error = false;
    const userData = {};

    formData.forEach((v, k) => {
        if (!v) {
            errors[k].setAttribute('data-error', true), error = true;
        } else {
            if (k === 'firstName' && !firstNameRegex.test(v)) {
                return errors[k].setAttribute('data-error', true), error = true;
            } else if (k === 'lastName' && !lastNameRegex.test(v)) {
                return errors[k].setAttribute('data-error', true), error = true;
            } else if (k === 'phone' && !phoneRegex.test(v)) {
                return errors[k].setAttribute('data-error', true), error = true;
            } else if (k === 'email' && !emailRegex.test(v)) {
                return errors[k].setAttribute('data-error', true), error = true;
            } else if (k === 'message' <= 0) {
                    return errors[k].setAttribute('data-error', true), error = true;
                }

                errors[k].setAttribute('data-error', false), error = false;
                userData[k] = v;
                // console.log(userData)
            }
        });
    if (!error) {
        axios.post('http://212.83.176.255:3030/contact', userData)
            .then((response) => {
                console.log(response.data);
                alert("Votre message à bien été envoyé.")
            }).catch((error) => {
                console.error(error);
            });
    }
})